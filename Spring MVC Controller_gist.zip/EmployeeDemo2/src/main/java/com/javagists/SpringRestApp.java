package com.javagists;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestApp {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestApp.class, args);
	}
}
