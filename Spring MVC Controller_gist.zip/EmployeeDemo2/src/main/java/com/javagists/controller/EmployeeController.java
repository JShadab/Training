package com.javagists.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.javagists.model.Employee;
import com.javagists.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	/**
	 * This is for saving new employee's data
	 */
	@RequestMapping(value = "/employee", method = RequestMethod.POST)
	public Employee addEmployee(Employee employee) {

		return employeeService.addEmployee(employee);

	}

	/**
	 * This is for updating existing employee's data
	 */
	@RequestMapping(value = "/employee", method = RequestMethod.PUT)
	public void updateEmployee(Employee employee) {

		employeeService.updateEmployee(employee);
	}

	/**
	 * This is for deleting existing employee's data
	 */
	@RequestMapping(value = "/employee/{id}", method = RequestMethod.DELETE)
	public boolean deleteEmployee(@PathVariable Long id) {

		return employeeService.deleteEmployee(id);
	}

	/**
	 * This is for retrieving particular employee data by using employee id in JSON(default) format.
	 */
	@RequestMapping(value = "/employeeJSON/{id}", method = RequestMethod.GET)
	public Employee getEmployeeJSON(@PathVariable Long id) {

		return employeeService.getEmployee(id);
	}

	/**
	 * This is for retrieving particular employee data by using employee id in XML format.
	 */
	@RequestMapping(value = "/employeeXML/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_XML_VALUE)
	public Employee getEmployeeXML(@PathVariable Long id) {

		return employeeService.getEmployee(id);
	}

	/**
	 * This is for retrieving particular employee data by using employee id.
	 */
	@RequestMapping(value = "/employee", method = RequestMethod.GET, produces = MediaType.APPLICATION_XML_VALUE)
	public List<Employee> getAllEmployees() {

		return employeeService.getAllEmployee();
	}

}
