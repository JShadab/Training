package com.javagists.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Service;

import com.javagists.model.Employee;

@Service
public class EmployeeService {

	private List<Employee> allEmployees;
	private Random random;

	public EmployeeService() {
		allEmployees = new ArrayList<>();

		random = new Random();
	}

	public Employee addEmployee(Employee employee) {

		Long index = new Long(random.nextInt(10000));
		employee.setId(index);

		allEmployees.add(employee);

		return employee;
	}

	public void updateEmployee(Employee employee) {

		Long id = employee.getId();

		for (Employee emp : allEmployees) {

			if (id == emp.getId()) {

				int index = allEmployees.indexOf(emp);

				allEmployees.set(index, employee);

				break;

			}

		}

	}

	public boolean deleteEmployee(Long id) {

		for (Employee emp : allEmployees) {

			if (id.equals(emp.getId())) {

				allEmployees.remove(emp);

				return true;

			}

		}

		return false;
	}

	public Employee getEmployee(Long id) {

		for (Employee emp : allEmployees) {

			if (id.equals(emp.getId())) {

				return emp;

			}

		}

		return null;
	}

	public List<Employee> getAllEmployee() {

		return allEmployees;
	}
}
