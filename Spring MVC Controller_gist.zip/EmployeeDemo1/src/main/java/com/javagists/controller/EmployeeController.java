package com.javagists.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.javagists.model.Employee;
import com.javagists.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	/**
	 * Shows addEmployee.html page with new employee having no data.
	 * 
	 * @return name of addEmployee page.
	 */
	@RequestMapping(value = "/addEmployeePage")
	public String getAddEmployeePage(Model model) {

		model.addAttribute("employee", new Employee());
		return "addEmployee";
	}

	/**
	 * Save new employee's data and redirect to employees.html
	 */
	@RequestMapping(value = "/employee", method = RequestMethod.POST)
	public String addEmployee(Employee employee) {

		employeeService.addEmployee(employee);

		return "redirect:employees";
	}

	/**
	 * Shows updateEmployee.html page with existing employee data retrieved by data
	 * layer using employee id.
	 * 
	 * @return name of updateEmployee page.
	 */
	@RequestMapping(value = "/updateEmployeePage/{id}")
	public String getUpdateEmplyeePage(@PathVariable Long id, Model model) {

		Employee emp = employeeService.getEmployee(id);

		model.addAttribute("employee", emp);

		return "updateEmployee";
	}

	/**
	 * Update existing employee's data and redirect to employees.html
	 */
	@RequestMapping(value = "/employee", method = RequestMethod.PUT)
	public String updateEmployee(Employee employee) {

		employeeService.updateEmployee(employee);

		return "redirect:employees";
	}

	/**
	 * Delete existing employee's data and redirect to employees.html
	 */
	@RequestMapping(value = "/employee/{id}", method = RequestMethod.DELETE)
	public String deleteEmployee(int id) {

		employeeService.deleteEmployee(id);

		return "redirect:employees";
	}

	/**
	 * Find all employees data from data layer and will rendered on employees.html
	 * page.
	 * 
	 * @return employees.html page name.
	 */
	@RequestMapping(value = "/employees", method = RequestMethod.GET)
	public String getAllEmployee(Model model) {

		model.addAttribute("employees", employeeService.getAllEmployee());

		return "employees";
	}

	/**
	 * This is for retrieving particular employee data by using employee id in JSON(default) format.
	 */
	@RequestMapping(value = "/employeeJSON/{id}", method = RequestMethod.GET)
	@ResponseBody
	public Employee getEmployeeJSON(@PathVariable Long id) {

		return employeeService.getEmployee(id);
	}
	
}
